<?php

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );
?>

	<header id="content-header">
		<h2>Offline</h2>
	</header><!-- / #content-header -->
	
	<section class="main section">
		We are offline now
	</section>

