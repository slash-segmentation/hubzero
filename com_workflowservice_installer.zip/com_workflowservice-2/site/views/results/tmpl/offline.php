<?php

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

if (isset($this->message)) {
	JError::raiseWarning( 100, $this->message );
}