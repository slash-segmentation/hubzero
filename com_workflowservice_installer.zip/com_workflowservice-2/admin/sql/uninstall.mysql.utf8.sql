-- $Id: uninstall.mysql.utf8.sql 59 2010-11-27 14:17:52Z chdemko $

DROP TABLE IF EXISTS `#__workflowservice_categories`;

delete from `#__menu`
where component_id IN (
select distinct extension_id
from `#__extensions`
where element = 'com_workflowservice'
)