-- $Id: uninstall.mysql.utf8.sql 59 2010-11-27 14:17:52Z chdemko $

DROP TABLE IF EXISTS `#__workflowservice_categories`;