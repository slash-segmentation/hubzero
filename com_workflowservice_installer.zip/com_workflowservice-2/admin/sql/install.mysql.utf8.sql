-- $Id: install.mysql.utf8.sql 60 2010-11-27 18:45:40Z chdemko $

DROP TABLE IF EXISTS `#__workflowservice_categories`;
 
CREATE TABLE `#__workflowservice_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(256) NOT NULL,
  `state` int(3) NOT NULL DEFAULT '1',
  `workflows` TEXT,
  `created` DATETIME NOT NULL,
  `ordering` int(3) NOT NULL DEFAULT '1',
   PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;
 
INSERT INTO `#__workflowservice_categories` (`category`, `ordering`, `state`) VALUES
        ('Hidden', 1, 1);

DROP TABLE IF EXISTS `#__workflowservice_workflows`;

CREATE TABLE `jos_workflowservice_workflows` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `workflow` varchar(128) NOT NULL DEFAULT '',
  `cat_id` smallint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

select @max_rgt:=max(rgt) as max_rgt from jos_menu;

INSERT INTO `#__extensions` (name, type, element, manifest_cache, params, custom_data, system_data, folder, client_id)
VALUES ('CRBSplaceholder', 'component', 'crbsplaceholder', '', '', '', '', '', 0);

SELECT @extension_id:=LAST_INSERT_ID() FROM `#__menu` limit 1;

INSERT INTO `#__menu` (menutype, title, alias, path, type, published, level, component_id, lft, rgt, link, img, params, parent_id, access) VALUES (
'mainmenu', 
'Workflow Service', 
'workflowservice', 
'workflowservice', 
'url', 
1, 
1, 
@extension_id, 
@max_rgt +1, 
@max_rgt +8, 
'workflowservice', 
'', 
'', 
1, 
2);


SELECT @last_id:=LAST_INSERT_ID() FROM `#__menu` limit 1;

INSERT INTO `#__menu` (menutype, title, alias, path, type, published, level, component_id, lft, rgt, link, img, params, parent_id, access) VALUES (
'mainmenu', 
'Jobs', 
'workflowservice-jobs', 
'workflowservice/jobs', 
'url', 
1, 
2, 
@extension_id, 
@max_rgt +2, 
@max_rgt +3, 
'workflowservice/jobs', 
'', 
'', 
@last_id, 
2);

INSERT INTO `#__menu` (menutype, title, alias, path, type, published, level, component_id, lft, rgt, link, img, params, parent_id, access) VALUES (
'mainmenu', 
'Workspace Files', 
'workflowservice-workspacefiles', 
'workflowservice/workspacefiles', 
'url', 
1, 
2, 
@extension_id, 
@max_rgt +4, 
@max_rgt +5, 
'workflowservice/workspacefiles', 
'', 
'', 
@last_id, 
2);

INSERT INTO `#__menu` (menutype, title, alias, path, type, published, level, component_id, lft, rgt, link, img, params, parent_id, access) VALUES (
'mainmenu', 
'Workflows', 
'workflowservice', 
'workflowservice', 
'url', 
1, 
2, 
@extension_id, 
@max_rgt +6, 
@max_rgt +7, 
'workflowservice', 
'', 
'', 
@last_id, 
2);